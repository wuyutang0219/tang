# Collecting Docker Log Files with Fluentd and sending to GCP.

The image was moved to the
[new location](https://github.com/kubernetes/contrib/tree/master/fluentd/fluentd-gcp-image).

[![Analytics](https://kubernetes-site.appspot.com/UA-36037335-10/GitHub/cluster/addons/fluentd-gcp/fluentd-gcp-image/README.md?pixel)]()
